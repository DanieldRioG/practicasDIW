addEventListener("DOMContentLoaded", () => {

    let light = document.getElementById("light");
    let heat = document.getElementById("heating");
    let air = document.getElementById("air");
    let plant = document.getElementById("plant");
    let coffee = document.getElementById("coffee");

    light.addEventListener("click", () => {
        location.href = "bombilla.html";
    });
    heat.addEventListener("click", () => {
        location.href = "bombilla.html";
    });
    air.addEventListener("click", () => {
        location.href = "bombilla.html";
    });
    plant.addEventListener("click", () => {
        location.href = "bombilla.html";
    });
    coffee.addEventListener("click", () => {
        location.href = "bombilla.html";
    });
});